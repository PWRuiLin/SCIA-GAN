# python3
from .compression import compress_jpeg
from .decompression import decompress_jpeg
