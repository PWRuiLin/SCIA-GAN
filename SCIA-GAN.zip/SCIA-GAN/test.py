from torch.utils.data import DataLoader
from utils import *
from network.Network import *
import math
from utils.load_test_setting import *
from evaluation_metrics.calculate_PSNR_SSIM import calculate_PSNR_SSIM,calculate_PSNR_SSIM1
from evaluation_metrics.calculate_APD_RMSE import calculate_APD_RMSE_MAE

from network.noise_layers.rotation_stretching import Rotation
import torch.nn.functional as F
def computePSNR(origin,pred):
    origin = np.array(origin)
    origin = origin.astype(np.float32)
    pred = np.array(pred)
    pred = pred.astype(np.float32)
    mse = np.mean((origin/1.0 - pred/1.0) ** 2 )
    if mse < 1.0e-10:
      return 100
    return 10 * math.log10(255.0**2/mse)
'''
test
'''
from Evaluation import mse_loss_fn1, ssim_loss, calculate_psnr, decoded_message_error_rate_batch, Bit_Error_Rate, Bit_Accuracy_Rate
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


network = Network_New(H, W, message_length, noise_layers, device, batch_size, lr, with_diffusion)
EC_path = result_folder + "models/EC_" + str(model_epoch) + ".pth" #TRAIN_EC_	 EC_
network.load_model_ed(EC_path)

Rotation = Rotation(45)
test_dataset = DATA_test(os.path.join(dataset_path, "Imagenet 3000"), H, W) #validation1000   test  TESTCOCO1
test_dataloader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=0, pin_memory=True)
#validation3000 PASCAL VOC2012 1000 Imagenet 3000 EUVP 600
print("\nStart Testing : \n\n")

test_result = {
	"error_rate": 0.0,
	"psnr": 0.0,
	"ssim": 0.0,
	# "psnr_noise": 0.0,
	# "ssim_noise": 0.0
}

start_time = time.time()

saved_iterations = np.random.choice(np.arange(len(test_dataset)), size=save_images_number, replace=False)
saved_all = None

num = 0
time_total = 0
for i, images in enumerate(test_dataloader):
	image = images.to(device)
	message = torch.Tensor(np.random.choice([0, 1], (image.shape[0], message_length))).to(device)
	# print(images.shape)
	'''
	test
	'''
	network.encoder_decoder.eval()
	network.discriminator.eval()
	with torch.no_grad():
		# use device to compute
		start_i = time.time()
		images, messages = images.to(network.device), message.to(network.device)
		encoded_images = network.encoder_decoder.module.encoder(images, messages)
		encoded_images = images + (encoded_images - image) * strength_factor
		noised_images = network.encoder_decoder.module.noise([encoded_images, images])
		# noised_images1, noised_images2, noised_images=Rotation([encoded_images, images])
		decoded_messages = network.encoder_decoder.module.decoder(noised_images)

		# print(f'messages={messages} | blank_messages={blank_messages} | decoded_messages={decoded_messages}')
		end_i = time.time()
		time_total = time_total + (end_i-start_i)

		# psnr = kornia.losses.psnr_loss(images, encoded_images, 2).item()  # encoded_images.detach()
		# psnr_noise = kornia.losses.psnr_loss(images, noised_images, 2).item()  # encoded_images.detach()
		# ssim = 1 - 2 * kornia.losses.ssim_loss(encoded_images.detach(), images, window_size=5, reduction="mean").item()
		# ssim_noise = 1 - 2 * kornia.losses.ssim_loss(noised_images.detach(), images, window_size=5, reduction="mean").item()


		# psnr		# ssimtorch.clamp(encoded_images, 0.0, 1.0)
		# psnr = kornia.losses.psnr_loss(encoded_images.detach(), images, 2).item()  #归一化得用2   没有的话用1
		ssim = 1 - 2 * kornia.losses.ssim_loss(encoded_images.detach(), images, window_size=5, reduction="mean").item()
		# psnr = kornia.losses.psnr_loss(torch.clamp(encoded_images, 0.0, 1.0).detach(), images, 1).item()  #归一化得用4   没有的话用2
		# ssim = 1 - 2 * kornia.losses.ssim_loss(torch.clamp(encoded_images, 0.0, 1.0).detach(), images, window_size=5, reduction="mean").item()

		# torchvision.utils.save_image(images, '/media/WRL/D/WRL/MBRS-main/' + result_folder + '/cover' + '' + '%.d.' % (i) + "png")
		# torchvision.utils.save_image(encoded_images, '/media/WRL/D/WRL/MBRS-main/' + result_folder + 'stego' + '' + '%.d.' % i +  "png")
		# torchvision.utils.save_image(noised_images, '/media/WRL/D/WRL/MBRS-main/' + result_folder + 'noise' + '' + '%.d.' % i + "png")
		# torchvision.utils.save_image(encoded_images-images, '/media/WRL/D/WRL/MBRS-main/image/test/noise/' + '' + '%.d.' % i + "png")
		# torchvision.utils.save_image(noised_images, '/media/WRL/D/WRL/MBRS-main/image/test/noise/' + '' + '%.d.' % i + "png")

		images_pad = F.pad(images, (5, 5, 5, 5), value=1.0)
		encoded_images_pad = F.pad(encoded_images, (5, 5, 5, 5), value=1.0)
		noised_images_pad = F.pad(noised_images, (5, 5, 5, 5), value=1.0)
		combination_images = torch.cat((images_pad, encoded_images_pad, noised_images_pad), dim=2)
		if i < 50:
			torchvision.utils.save_image(combination_images,'/media/WRL/D/WRL/MBRS-main/' + result_folder + '/combination/' + '' + '%.d.' % i + "png")

		encoded_images1 = encoded_images.permute(2, 3, 1, 0).cpu().numpy().squeeze() * 255
		encoded_images1 = np.clip(encoded_images1, 0, 255)
		images1 = images.permute(2, 3, 1, 0).cpu().numpy().squeeze() * 255
		images1 = np.clip(images1, 0, 255)
		noised_images1 = noised_images.permute(2, 3, 1, 0).cpu().numpy().squeeze() * 255
		noised_images1 = np.clip(noised_images1, 0, 255)
		psnr, ssimm = calculate_PSNR_SSIM1(images1, encoded_images1)

	error_rate = decoded_message_error_rate_batch(messages, decoded_messages)

	result = {
		"error_rate": error_rate,
		"psnr": psnr,
		"ssim": ssim,
	}

	for key in result:
		test_result[key] += float(result[key])

	num += 1

	if i in saved_iterations:
		if saved_all is None:
			saved_all = get_random_images(image, encoded_images, noised_images)
		else:
			saved_all = concatenate_images(saved_all, image, encoded_images, noised_images)

	'''
	test results
	'''
	content = "Image " + str(num) + " : \n"
	for key in test_result:
		content += key + "=" + str(result[key]) + ","
	content += "\n"

	with open(test_log, "a") as file:
		file.write(content)

	print(content)
# PSNR_all, SSIM_all = calculate_PSNR_SSIM(test_Y=False, secret=False, cover=True, img="png")
# print(f' secret | PSNR_AVE={sum(PSNR_all) / len(PSNR_all)} | SSIM_AVE={sum(SSIM_all) / len(SSIM_all)} ')
'''
test results
'''

content = "Average : \n"
for key in test_result:
	content += key + "=" + str(test_result[key] / num) + ","
content += "\n"

with open(test_log, "a") as file:
	file.write(content)

print(content)
print(time_total)
save_images(saved_all, "test", result_folder + "images/", resize_to=(W, H))

##############################################################################################################################
# DATA_test COCO        1.39
# Identity()			error_rate=1.1111111111111112e-05,psnr=31.090548500327625,ssim=0.856687427594016
# JpegTest(50)			error_rate=0.07825555555555339,psnr=31.10120121181066,ssim=0.8570598292065164
# C(0.035)				error_rate=0.05261111111111005,psnr=31.112130178739424,ssim=0.8573109937260548
# CO(0.3)				error_rate=0.0,psnr=31.095372093704718,ssim=0.8567498432757954
# DO(0.3)				error_rate=0.0,psnr=31.08964871624327,ssim=0.8566339654723804,
# GN(0.01)				error_rate=8.888888888888889e-05,psnr=31.10533168271363,ssim=0.8570578373546401
# GB(2)					error_rate=0.0,psnr=31.091710643697404,ssim=0.856685850597918,
# MB(3)					error_rate=0.0,psnr=31.098637162165463,ssim=0.8569724850890537
# SP(0.04)				error_rate=0.0,psnr=31.108569318836352,ssim=0.8569766602541009

# DATA_test ImageNet	1.39
# Identity()			error_rate=8.888888888888889e-05,psnr=31.010594002150658,ssim=0.8579204111713916
# JpegTest(50)			error_rate=0.085633333333331,psnr=31.003991982118826,ssim=0.8579080308228731
# C(0.035)				error_rate=0.052877777777776594,psnr=31.008109791782612,ssim=0.8579325875416398
# CO(0.3)				error_rate=0.0,psnr=31.0084443347815,ssim=0.857960908226048
# DO(0.3)				error_rate=0.0,psnr=31.004566567228355,ssim=0.857787844825536
# GN(0.01)				error_rate=0.00017777777777777779,psnr=30.997390280379808,ssim=0.857530780704692
# GB(2)					error_rate=0.0,psnr=31.001950133246485,ssim=0.8578122552217294
# MB(3)					error_rate=0.0,psnr=31.009822736179053,ssim=0.8578049984015524
# SP(0.04)				error_rate=4.4444444444444447e-05,psnr=31.01127002398435,ssim=0.8579363888123384
################################################################上可180 206   下
# DATA_test COCO        1.33
# Identity() 			error_rate=0.056099999999999615,psnr=36.14644186528524,psnr=30.230161844423172,ssim=0.8406599912891786
# JpegTest(50)			error_rate=0.06257777777777612,psnr=36.153613448460895,ssim=0.8570280174660052
# C(0.035)              error_rate=0.04591111111111032,psnr=36.144886566797894,ssim=0.8568046731290287
# CO(0.3)				error_rate=0.0,psnr=36.155114980061846,ssim=0.8570622225726988
# DO(0.3)				error_rate=0.00012222222222222221,psnr=36.16163032595317,ssim=0.8573042550079769
# GN(0.01)				error_rate=0.003966666666666657,psnr=30.230375137934523,ssim=0.8405747483658293,
# GB(2)					error_rate=0.0,psnr=36.15373577054341,ssim=0.8568647989841872
# MB(3)					error_rate=0.0,psnr=30.231232436302797,ssim=0.8405745568287869
# SP(0.04)				error_rate=0.0066444444444444615,psnr=30.242377217882648,ssim=0.8408664667370419

# DATA_test ImageNet	1.33
# Identity()			error_rate=0.05794444444444403,psnr=35.98229983647664,psnr=30.08992465848319,ssim=0.8415043882963558
# JpegTest(50)			error_rate=0.06956666666666492,psnr=35.98596495564779,ssim=0.8602862190279805
# C(0.035)				error_rate=0.046999999999999174,psnr=35.9893546965917,ssim=0.8604536941685074
# CO(0.3)				error_rate=0.0,psnr=35.98624719174703,ssim=0.8603355869478669
# DO(0.3)				error_rate=0.00014444444444444444,psnr=35.99514280192057,ssim=0.8606655072894807
# GN(0.01)				error_rate=0.004044444444444435,psnr=30.106589783502404,ssim=0.8419097935240716
# GB(2)					error_rate=0.0,psnr=35.98539020983378,ssim=0.8602235641703836
# MB(3)					error_rate=0.0,psnr=30.092474558879122,ssim=0.8415409108040234
# SP(0.04)				error_rate=0.006344444444444459,psnr=30.07607901736122,ssim=0.8408393009118735
##############################################################################################################################
#训练本文使用的组合噪声的测试结果 FCL
# DATA_test COCO        1.2855
# Identity() 			error_rate=0.0,psnr=35.09930528004964,psnr=29.19809611742308,ssim=0.8389014235697687
# JpegTest(50)			error_rate=0.09311111111110992
# C(0.035)				error_rate=0.07179999999999817
# CO(0.3)				error_rate=5.555555555555555e-05
# DO(0.3)				error_rate=0.0
# GB(2)					error_rate=0.0
#训练多种组合的测试结果  MLP
# DATA_test COCO        1.4
# Identity() 			error_rate=0.00887777777777782,psnr=35.94704923375448,psnr=30.052232337372544,ssim=0.827610719713072
# JpegTest(50)			error_rate=0.14327777777777836
# C(0.035)              error_rate=0.035133333333332996
# CO(0.3)				error_rate=0.0
# DO(0.3)				error_rate=0.0
# GB(2)					error_rate=0.0
##############################################################################################################################
#损失比例
# 1 01 0.0001
# Identity()error_rate=0.0,psnr=42.76267918395996,psnr=36.77269181278604,ssim=0.9564122033249587,
# JPEG(50) 	error_rate=0.035587890625
# JPEG(70) 	error_rate=0.0002421875
# JPEG(90)  error_rate=2.9296875e-06,
# 1 05 0.0001
# Identity()error_rate=0.0,psnr=42.77854087575277, psnr=36.769322673807764,ssim=0.950997671848163
# JPEG(50) 	error_rate=0.02313671875
# JPEG(70) 	error_rate=2.05078125e-05
# JPEG(90) 	error_rate=0.0
# 1 10 0.0001
# Identity()error_rate=0.0,psnr=42.47394975535075,psnr=36.468668324810125,ssim=0.9465777700394392
# JPEG(50) 	error_rate=0.0258115234375
# JPEG(70) 	error_rate=0.000216796875
# JPEG(90) 	error_rate=0.0
# 1 15 0.0001
# Identity()error_rate=0.0,psnr=42.381716623942054,psnr=36.36923989089175,ssim=0.9513505619652569
# JPEG(50) 	error_rate=0.0235029296875
# JPEG(70) 	error_rate=0.00021484375
# JPEG(90) 	error_rate=9.765625e-07
# 1 20 0.0001
# Identity()error_rate=0.0,psnr=42.19619543965658,psnr=36.18252538807596,ssim=0.952532847840339
# JPEG(50) 	error_rate=0.0243017578125
# JPEG(70) 	error_rate=0.000408203125
# JPEG(90) 	error_rate=9.765625e-07
##############################################################################################################################
#损失
# no  no
# Identity()error_rate=9.765625e-07,psnr=42.05028998184204,psnr=36.06138412996845,ssim=0.9545475801602006,
# JPEG(50) 	error_rate=0.037974609375
# JPEG(70) 	error_rate=0.002796875
# yes no
# Identity()error_rate=0.0,psnr=42.199949333190915,error_rate=0.0,psnr=36.19612404565247,ssim=0.9524406026303768,
# JPEG(50) 	error_rate=0.0304794921875
# JPEG(70)  error_rate=0.0008359375
# yes yes
# Identity()error_rate=0.0,psnr=42.77854087575277, psnr=36.769322673807764,ssim=0.950997671848163
# JPEG(50) 	error_rate=0.02313671875
# JPEG(70) 	error_rate=2.05078125e-05
##############################################################################################################################
#注意力 CA  SA
# 	CAA:No  No
# Identity()	error_rate=0.0,psnr=42.21230578994751,psnr=36.21760002631458,ssim=0.9528342836536468
# JPEG(50)		error_rate=0.030841796875
# JPEG(70)		error_rate=0.0011826171875
# 	CA:	Yes No
# Identity()	error_rate=0.0,psnr=42.52165929412842,psnr=36.52463741099738,ssim=0.9505605815760791,
# JPEG(50)		error_rate=0.0258388671875
# JPEG(70)		error_rate=0.00027734375
# 	CASA
# Identity()	error_rate=0.0,psnr=40.796114013671875,psnr=34.817253130746785,ssim=0.9370189934596419
# JPEG(50)		error_rate=0.0371787109375
# JPEG(70)		error_rate=0.001427734375
# 	SACA
# Identity()	error_rate=0.0,psnr=41.25640808105469,psnr=35.272175972406714,ssim=0.9345148190017789,
# JPEG(50)		error_rate=0.031693359375
# JPEG(70)		error_rate=0.0015595703125




#JPEG Test compare
#30 bit
# Identity()error_rate=0.0,psnr=36.250759488207144,ssim=0.9576781198401004,
# JPEG(50)	error_rate=0.0007333333333333332,psnr=36.24066776682695,ssim=0.9576471395641565,
# JPEG(70)	error_rate=0.0,psnr=36.2476998765132,ssim=0.9576680885329842,
# JPEG(90)	error_rate=0.0,psnr=36.25400911643829,ssim=0.9577002228796482,
